﻿namespace Week_4___Radio_Button
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelCountry = new System.Windows.Forms.Label();
            this.radioButtonAustralia = new System.Windows.Forms.RadioButton();
            this.radioButtonNewZealand = new System.Windows.Forms.RadioButton();
            this.radioButtonUSA = new System.Windows.Forms.RadioButton();
            this.radioButtonJapan = new System.Windows.Forms.RadioButton();
            this.radioButtonChina = new System.Windows.Forms.RadioButton();
            this.radioButtonThumbNail = new System.Windows.Forms.RadioButton();
            this.radioButtonFullSize = new System.Windows.Forms.RadioButton();
            this.groupBoxCountry = new System.Windows.Forms.GroupBox();
            this.groupBoxImageSize = new System.Windows.Forms.GroupBox();
            this.pictureBoxFlag = new System.Windows.Forms.PictureBox();
            this.buttonAbout = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBoxCountry.SuspendLayout();
            this.groupBoxImageSize.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFlag)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(94, 21);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(439, 25);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Flags of the World by Nelson LAI s10000399";
            // 
            // labelCountry
            // 
            this.labelCountry.AutoSize = true;
            this.labelCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountry.Location = new System.Drawing.Point(185, 239);
            this.labelCountry.Name = "labelCountry";
            this.labelCountry.Size = new System.Drawing.Size(56, 13);
            this.labelCountry.TabIndex = 1;
            this.labelCountry.Text = "Austraila";
            this.labelCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radioButtonAustralia
            // 
            this.radioButtonAustralia.AutoSize = true;
            this.radioButtonAustralia.Location = new System.Drawing.Point(21, 28);
            this.radioButtonAustralia.Name = "radioButtonAustralia";
            this.radioButtonAustralia.Size = new System.Drawing.Size(65, 17);
            this.radioButtonAustralia.TabIndex = 2;
            this.radioButtonAustralia.TabStop = true;
            this.radioButtonAustralia.Text = "Australia";
            this.radioButtonAustralia.UseVisualStyleBackColor = true;
            this.radioButtonAustralia.CheckedChanged += new System.EventHandler(this.radioButtonAustralia_CheckedChanged);
            // 
            // radioButtonNewZealand
            // 
            this.radioButtonNewZealand.AutoSize = true;
            this.radioButtonNewZealand.Location = new System.Drawing.Point(21, 56);
            this.radioButtonNewZealand.Name = "radioButtonNewZealand";
            this.radioButtonNewZealand.Size = new System.Drawing.Size(89, 17);
            this.radioButtonNewZealand.TabIndex = 3;
            this.radioButtonNewZealand.TabStop = true;
            this.radioButtonNewZealand.Text = "New Zealand";
            this.radioButtonNewZealand.UseVisualStyleBackColor = true;
            this.radioButtonNewZealand.CheckedChanged += new System.EventHandler(this.radioButtonNewZealand_CheckedChanged);
            // 
            // radioButtonUSA
            // 
            this.radioButtonUSA.AutoSize = true;
            this.radioButtonUSA.Location = new System.Drawing.Point(21, 84);
            this.radioButtonUSA.Name = "radioButtonUSA";
            this.radioButtonUSA.Size = new System.Drawing.Size(47, 17);
            this.radioButtonUSA.TabIndex = 4;
            this.radioButtonUSA.TabStop = true;
            this.radioButtonUSA.Text = "USA";
            this.radioButtonUSA.UseVisualStyleBackColor = true;
            this.radioButtonUSA.CheckedChanged += new System.EventHandler(this.radioButtonUSA_CheckedChanged);
            // 
            // radioButtonJapan
            // 
            this.radioButtonJapan.AutoSize = true;
            this.radioButtonJapan.Location = new System.Drawing.Point(21, 112);
            this.radioButtonJapan.Name = "radioButtonJapan";
            this.radioButtonJapan.Size = new System.Drawing.Size(54, 17);
            this.radioButtonJapan.TabIndex = 5;
            this.radioButtonJapan.TabStop = true;
            this.radioButtonJapan.Text = "Japan";
            this.radioButtonJapan.UseVisualStyleBackColor = true;
            this.radioButtonJapan.CheckedChanged += new System.EventHandler(this.radioButtonJapan_CheckedChanged);
            // 
            // radioButtonChina
            // 
            this.radioButtonChina.AutoSize = true;
            this.radioButtonChina.Location = new System.Drawing.Point(21, 140);
            this.radioButtonChina.Name = "radioButtonChina";
            this.radioButtonChina.Size = new System.Drawing.Size(52, 17);
            this.radioButtonChina.TabIndex = 6;
            this.radioButtonChina.TabStop = true;
            this.radioButtonChina.Text = "China";
            this.radioButtonChina.UseVisualStyleBackColor = true;
            this.radioButtonChina.CheckedChanged += new System.EventHandler(this.radioButtonChina_CheckedChanged);
            // 
            // radioButtonThumbNail
            // 
            this.radioButtonThumbNail.AutoSize = true;
            this.radioButtonThumbNail.Location = new System.Drawing.Point(21, 31);
            this.radioButtonThumbNail.Name = "radioButtonThumbNail";
            this.radioButtonThumbNail.Size = new System.Drawing.Size(79, 17);
            this.radioButtonThumbNail.TabIndex = 7;
            this.radioButtonThumbNail.TabStop = true;
            this.radioButtonThumbNail.Text = "Thumb Nail";
            this.radioButtonThumbNail.UseVisualStyleBackColor = true;
            this.radioButtonThumbNail.CheckedChanged += new System.EventHandler(this.radioButtonThumbNail_CheckedChanged);
            // 
            // radioButtonFullSize
            // 
            this.radioButtonFullSize.AutoSize = true;
            this.radioButtonFullSize.Enabled = false;
            this.radioButtonFullSize.Location = new System.Drawing.Point(21, 59);
            this.radioButtonFullSize.Name = "radioButtonFullSize";
            this.radioButtonFullSize.Size = new System.Drawing.Size(64, 17);
            this.radioButtonFullSize.TabIndex = 8;
            this.radioButtonFullSize.TabStop = true;
            this.radioButtonFullSize.Text = "Full Size";
            this.radioButtonFullSize.UseVisualStyleBackColor = true;
            this.radioButtonFullSize.CheckedChanged += new System.EventHandler(this.radioButtonFullSize_CheckedChanged);
            // 
            // groupBoxCountry
            // 
            this.groupBoxCountry.Controls.Add(this.radioButtonAustralia);
            this.groupBoxCountry.Controls.Add(this.radioButtonNewZealand);
            this.groupBoxCountry.Controls.Add(this.radioButtonUSA);
            this.groupBoxCountry.Controls.Add(this.radioButtonJapan);
            this.groupBoxCountry.Controls.Add(this.radioButtonChina);
            this.groupBoxCountry.Location = new System.Drawing.Point(12, 60);
            this.groupBoxCountry.Name = "groupBoxCountry";
            this.groupBoxCountry.Size = new System.Drawing.Size(148, 180);
            this.groupBoxCountry.TabIndex = 9;
            this.groupBoxCountry.TabStop = false;
            this.groupBoxCountry.Text = "Country";
            // 
            // groupBoxImageSize
            // 
            this.groupBoxImageSize.Controls.Add(this.radioButtonFullSize);
            this.groupBoxImageSize.Controls.Add(this.radioButtonThumbNail);
            this.groupBoxImageSize.Location = new System.Drawing.Point(12, 276);
            this.groupBoxImageSize.Name = "groupBoxImageSize";
            this.groupBoxImageSize.Size = new System.Drawing.Size(148, 100);
            this.groupBoxImageSize.TabIndex = 10;
            this.groupBoxImageSize.TabStop = false;
            this.groupBoxImageSize.Text = "Image Size";
            // 
            // pictureBoxFlag
            // 
            this.pictureBoxFlag.Image = global::Week_4___Radio_Button.Properties.Resources.USAFlag;
            this.pictureBoxFlag.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxFlag.Name = "pictureBoxFlag";
            this.pictureBoxFlag.Size = new System.Drawing.Size(417, 213);
            this.pictureBoxFlag.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxFlag.TabIndex = 11;
            this.pictureBoxFlag.TabStop = false;
            // 
            // buttonAbout
            // 
            this.buttonAbout.Location = new System.Drawing.Point(3, 290);
            this.buttonAbout.Name = "buttonAbout";
            this.buttonAbout.Size = new System.Drawing.Size(417, 23);
            this.buttonAbout.TabIndex = 12;
            this.buttonAbout.Text = "About";
            this.buttonAbout.UseVisualStyleBackColor = true;
            this.buttonAbout.Click += new System.EventHandler(this.buttonAbout_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Controls.Add(this.pictureBoxFlag);
            this.panel1.Controls.Add(this.buttonAbout);
            this.panel1.Controls.Add(this.labelCountry);
            this.panel1.Location = new System.Drawing.Point(193, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(419, 316);
            this.panel1.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBoxImageSize);
            this.Controls.Add(this.groupBoxCountry);
            this.Controls.Add(this.labelTitle);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(640, 480);
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "Form1";
            this.Text = "Exercise 4 - Radio Box s10000399";
            this.groupBoxCountry.ResumeLayout(false);
            this.groupBoxCountry.PerformLayout();
            this.groupBoxImageSize.ResumeLayout(false);
            this.groupBoxImageSize.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFlag)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelCountry;
        private System.Windows.Forms.RadioButton radioButtonAustralia;
        private System.Windows.Forms.RadioButton radioButtonNewZealand;
        private System.Windows.Forms.RadioButton radioButtonUSA;
        private System.Windows.Forms.RadioButton radioButtonJapan;
        private System.Windows.Forms.RadioButton radioButtonChina;
        private System.Windows.Forms.RadioButton radioButtonThumbNail;
        private System.Windows.Forms.RadioButton radioButtonFullSize;
        private System.Windows.Forms.GroupBox groupBoxCountry;
        private System.Windows.Forms.GroupBox groupBoxImageSize;
        private System.Windows.Forms.PictureBox pictureBoxFlag;
        private System.Windows.Forms.Button buttonAbout;
        private System.Windows.Forms.Panel panel1;
    }
}

