﻿namespace Exercise_5___Variable
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxMeat = new System.Windows.Forms.GroupBox();
            this.checkBoxTuna = new System.Windows.Forms.CheckBox();
            this.checkBoxAnchovise = new System.Windows.Forms.CheckBox();
            this.checkBoxPrawn = new System.Windows.Forms.CheckBox();
            this.checkBoxMince = new System.Windows.Forms.CheckBox();
            this.checkBoxHotSalami = new System.Windows.Forms.CheckBox();
            this.checkBoxSalami = new System.Windows.Forms.CheckBox();
            this.checkBoxChicken = new System.Windows.Forms.CheckBox();
            this.groupBoxPizzaBase = new System.Windows.Forms.GroupBox();
            this.radioButtonCrispyCrust = new System.Windows.Forms.RadioButton();
            this.radioButtonDeepPan = new System.Windows.Forms.RadioButton();
            this.radioButtonTraditionalCrust = new System.Windows.Forms.RadioButton();
            this.groupBoxDeliveryType = new System.Windows.Forms.GroupBox();
            this.radioButtonPickup = new System.Windows.Forms.RadioButton();
            this.radioButtonDelivered = new System.Windows.Forms.RadioButton();
            this.groupBoxSauces = new System.Windows.Forms.GroupBox();
            this.radioButtonGarlicSauce = new System.Windows.Forms.RadioButton();
            this.radioButtonTomato = new System.Windows.Forms.RadioButton();
            this.radioButtonChilliSauce = new System.Windows.Forms.RadioButton();
            this.radioButtonBBQSauce = new System.Windows.Forms.RadioButton();
            this.groupBoxReserve = new System.Windows.Forms.GroupBox();
            this.labelTitle = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxPhone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonSubmite = new System.Windows.Forms.Button();
            this.labelReserve = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonAbout = new System.Windows.Forms.Button();
            this.groupBoxMeat.SuspendLayout();
            this.groupBoxPizzaBase.SuspendLayout();
            this.groupBoxDeliveryType.SuspendLayout();
            this.groupBoxSauces.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxMeat
            // 
            this.groupBoxMeat.Controls.Add(this.checkBoxTuna);
            this.groupBoxMeat.Controls.Add(this.checkBoxAnchovise);
            this.groupBoxMeat.Controls.Add(this.checkBoxPrawn);
            this.groupBoxMeat.Controls.Add(this.checkBoxMince);
            this.groupBoxMeat.Controls.Add(this.checkBoxHotSalami);
            this.groupBoxMeat.Controls.Add(this.checkBoxSalami);
            this.groupBoxMeat.Controls.Add(this.checkBoxChicken);
            this.groupBoxMeat.Location = new System.Drawing.Point(424, 12);
            this.groupBoxMeat.Name = "groupBoxMeat";
            this.groupBoxMeat.Size = new System.Drawing.Size(188, 252);
            this.groupBoxMeat.TabIndex = 2;
            this.groupBoxMeat.TabStop = false;
            this.groupBoxMeat.Text = "Meat";
            // 
            // checkBoxTuna
            // 
            this.checkBoxTuna.AutoSize = true;
            this.checkBoxTuna.Location = new System.Drawing.Point(6, 221);
            this.checkBoxTuna.Name = "checkBoxTuna";
            this.checkBoxTuna.Size = new System.Drawing.Size(51, 17);
            this.checkBoxTuna.TabIndex = 6;
            this.checkBoxTuna.Text = "Tuna";
            this.checkBoxTuna.UseVisualStyleBackColor = true;
            this.checkBoxTuna.CheckedChanged += new System.EventHandler(this.checkBoxTuna_CheckedChanged);
            // 
            // checkBoxAnchovise
            // 
            this.checkBoxAnchovise.AutoSize = true;
            this.checkBoxAnchovise.Location = new System.Drawing.Point(6, 187);
            this.checkBoxAnchovise.Name = "checkBoxAnchovise";
            this.checkBoxAnchovise.Size = new System.Drawing.Size(76, 17);
            this.checkBoxAnchovise.TabIndex = 5;
            this.checkBoxAnchovise.Text = "Anchovies";
            this.checkBoxAnchovise.UseVisualStyleBackColor = true;
            this.checkBoxAnchovise.CheckedChanged += new System.EventHandler(this.checkBoxAnchovise_CheckedChanged);
            // 
            // checkBoxPrawn
            // 
            this.checkBoxPrawn.AutoSize = true;
            this.checkBoxPrawn.Location = new System.Drawing.Point(6, 153);
            this.checkBoxPrawn.Name = "checkBoxPrawn";
            this.checkBoxPrawn.Size = new System.Drawing.Size(56, 17);
            this.checkBoxPrawn.TabIndex = 4;
            this.checkBoxPrawn.Text = "Prawn";
            this.checkBoxPrawn.UseVisualStyleBackColor = true;
            this.checkBoxPrawn.CheckedChanged += new System.EventHandler(this.checkBoxPrawn_CheckedChanged);
            // 
            // checkBoxMince
            // 
            this.checkBoxMince.AutoSize = true;
            this.checkBoxMince.Location = new System.Drawing.Point(6, 120);
            this.checkBoxMince.Name = "checkBoxMince";
            this.checkBoxMince.Size = new System.Drawing.Size(55, 17);
            this.checkBoxMince.TabIndex = 3;
            this.checkBoxMince.Text = "Mince";
            this.checkBoxMince.UseVisualStyleBackColor = true;
            this.checkBoxMince.CheckedChanged += new System.EventHandler(this.checkBoxMince_CheckedChanged);
            // 
            // checkBoxHotSalami
            // 
            this.checkBoxHotSalami.AutoSize = true;
            this.checkBoxHotSalami.Location = new System.Drawing.Point(6, 90);
            this.checkBoxHotSalami.Name = "checkBoxHotSalami";
            this.checkBoxHotSalami.Size = new System.Drawing.Size(77, 17);
            this.checkBoxHotSalami.TabIndex = 2;
            this.checkBoxHotSalami.Text = "Hot Salami";
            this.checkBoxHotSalami.UseVisualStyleBackColor = true;
            this.checkBoxHotSalami.CheckedChanged += new System.EventHandler(this.checkBoxHotSalami_CheckedChanged);
            // 
            // checkBoxSalami
            // 
            this.checkBoxSalami.AutoSize = true;
            this.checkBoxSalami.Location = new System.Drawing.Point(6, 57);
            this.checkBoxSalami.Name = "checkBoxSalami";
            this.checkBoxSalami.Size = new System.Drawing.Size(57, 17);
            this.checkBoxSalami.TabIndex = 1;
            this.checkBoxSalami.Text = "Salami";
            this.checkBoxSalami.UseVisualStyleBackColor = true;
            this.checkBoxSalami.CheckedChanged += new System.EventHandler(this.checkBoxSalami_CheckedChanged);
            // 
            // checkBoxChicken
            // 
            this.checkBoxChicken.AutoSize = true;
            this.checkBoxChicken.Location = new System.Drawing.Point(6, 24);
            this.checkBoxChicken.Name = "checkBoxChicken";
            this.checkBoxChicken.Size = new System.Drawing.Size(65, 17);
            this.checkBoxChicken.TabIndex = 0;
            this.checkBoxChicken.Text = "Chicken";
            this.checkBoxChicken.UseVisualStyleBackColor = true;
            this.checkBoxChicken.CheckedChanged += new System.EventHandler(this.checkBoxChicken_CheckedChanged);
            // 
            // groupBoxPizzaBase
            // 
            this.groupBoxPizzaBase.Controls.Add(this.radioButtonCrispyCrust);
            this.groupBoxPizzaBase.Controls.Add(this.radioButtonDeepPan);
            this.groupBoxPizzaBase.Controls.Add(this.radioButtonTraditionalCrust);
            this.groupBoxPizzaBase.Location = new System.Drawing.Point(12, 12);
            this.groupBoxPizzaBase.Name = "groupBoxPizzaBase";
            this.groupBoxPizzaBase.Size = new System.Drawing.Size(200, 123);
            this.groupBoxPizzaBase.TabIndex = 2;
            this.groupBoxPizzaBase.TabStop = false;
            this.groupBoxPizzaBase.Text = "Pizza Base";
            // 
            // radioButtonCrispyCrust
            // 
            this.radioButtonCrispyCrust.AutoSize = true;
            this.radioButtonCrispyCrust.Location = new System.Drawing.Point(6, 93);
            this.radioButtonCrispyCrust.Name = "radioButtonCrispyCrust";
            this.radioButtonCrispyCrust.Size = new System.Drawing.Size(80, 17);
            this.radioButtonCrispyCrust.TabIndex = 2;
            this.radioButtonCrispyCrust.TabStop = true;
            this.radioButtonCrispyCrust.Text = "Crispy Crust";
            this.radioButtonCrispyCrust.UseVisualStyleBackColor = true;
            this.radioButtonCrispyCrust.CheckedChanged += new System.EventHandler(this.radioButtonCrispyCrust_CheckedChanged);
            // 
            // radioButtonDeepPan
            // 
            this.radioButtonDeepPan.AutoSize = true;
            this.radioButtonDeepPan.Location = new System.Drawing.Point(6, 58);
            this.radioButtonDeepPan.Name = "radioButtonDeepPan";
            this.radioButtonDeepPan.Size = new System.Drawing.Size(73, 17);
            this.radioButtonDeepPan.TabIndex = 1;
            this.radioButtonDeepPan.TabStop = true;
            this.radioButtonDeepPan.Text = "Deep Pan";
            this.radioButtonDeepPan.UseVisualStyleBackColor = true;
            this.radioButtonDeepPan.CheckedChanged += new System.EventHandler(this.radioButtonDeepPan_CheckedChanged);
            // 
            // radioButtonTraditionalCrust
            // 
            this.radioButtonTraditionalCrust.AutoSize = true;
            this.radioButtonTraditionalCrust.Location = new System.Drawing.Point(6, 24);
            this.radioButtonTraditionalCrust.Name = "radioButtonTraditionalCrust";
            this.radioButtonTraditionalCrust.Size = new System.Drawing.Size(101, 17);
            this.radioButtonTraditionalCrust.TabIndex = 0;
            this.radioButtonTraditionalCrust.TabStop = true;
            this.radioButtonTraditionalCrust.Text = "Traditional Crust";
            this.radioButtonTraditionalCrust.UseVisualStyleBackColor = true;
            this.radioButtonTraditionalCrust.CheckedChanged += new System.EventHandler(this.radioButtonTraditionalCrust_CheckedChanged);
            // 
            // groupBoxDeliveryType
            // 
            this.groupBoxDeliveryType.Controls.Add(this.radioButtonPickup);
            this.groupBoxDeliveryType.Controls.Add(this.radioButtonDelivered);
            this.groupBoxDeliveryType.Location = new System.Drawing.Point(218, 12);
            this.groupBoxDeliveryType.Name = "groupBoxDeliveryType";
            this.groupBoxDeliveryType.Size = new System.Drawing.Size(200, 123);
            this.groupBoxDeliveryType.TabIndex = 3;
            this.groupBoxDeliveryType.TabStop = false;
            this.groupBoxDeliveryType.Text = "Delivery Type";
            // 
            // radioButtonPickup
            // 
            this.radioButtonPickup.AutoSize = true;
            this.radioButtonPickup.Location = new System.Drawing.Point(6, 80);
            this.radioButtonPickup.Name = "radioButtonPickup";
            this.radioButtonPickup.Size = new System.Drawing.Size(58, 17);
            this.radioButtonPickup.TabIndex = 5;
            this.radioButtonPickup.TabStop = true;
            this.radioButtonPickup.Text = "Pickup";
            this.radioButtonPickup.UseVisualStyleBackColor = true;
            this.radioButtonPickup.CheckedChanged += new System.EventHandler(this.radioButtonPickup_CheckedChanged);
            // 
            // radioButtonDelivered
            // 
            this.radioButtonDelivered.AutoSize = true;
            this.radioButtonDelivered.Location = new System.Drawing.Point(6, 40);
            this.radioButtonDelivered.Name = "radioButtonDelivered";
            this.radioButtonDelivered.Size = new System.Drawing.Size(70, 17);
            this.radioButtonDelivered.TabIndex = 6;
            this.radioButtonDelivered.TabStop = true;
            this.radioButtonDelivered.Text = "Delivered";
            this.radioButtonDelivered.UseVisualStyleBackColor = true;
            this.radioButtonDelivered.CheckedChanged += new System.EventHandler(this.radioButtonDelivered_CheckedChanged);
            // 
            // groupBoxSauces
            // 
            this.groupBoxSauces.Controls.Add(this.radioButtonGarlicSauce);
            this.groupBoxSauces.Controls.Add(this.radioButtonTomato);
            this.groupBoxSauces.Controls.Add(this.radioButtonChilliSauce);
            this.groupBoxSauces.Controls.Add(this.radioButtonBBQSauce);
            this.groupBoxSauces.Location = new System.Drawing.Point(12, 141);
            this.groupBoxSauces.Name = "groupBoxSauces";
            this.groupBoxSauces.Size = new System.Drawing.Size(200, 123);
            this.groupBoxSauces.TabIndex = 3;
            this.groupBoxSauces.TabStop = false;
            this.groupBoxSauces.Text = "Sauces";
            // 
            // radioButtonGarlicSauce
            // 
            this.radioButtonGarlicSauce.AutoSize = true;
            this.radioButtonGarlicSauce.Location = new System.Drawing.Point(6, 93);
            this.radioButtonGarlicSauce.Name = "radioButtonGarlicSauce";
            this.radioButtonGarlicSauce.Size = new System.Drawing.Size(86, 17);
            this.radioButtonGarlicSauce.TabIndex = 4;
            this.radioButtonGarlicSauce.TabStop = true;
            this.radioButtonGarlicSauce.Text = "Garlic Sauce";
            this.radioButtonGarlicSauce.UseVisualStyleBackColor = true;
            this.radioButtonGarlicSauce.CheckedChanged += new System.EventHandler(this.radioButtonGarlicSauce_CheckedChanged);
            // 
            // radioButtonTomato
            // 
            this.radioButtonTomato.AutoSize = true;
            this.radioButtonTomato.Location = new System.Drawing.Point(6, 70);
            this.radioButtonTomato.Name = "radioButtonTomato";
            this.radioButtonTomato.Size = new System.Drawing.Size(61, 17);
            this.radioButtonTomato.TabIndex = 3;
            this.radioButtonTomato.TabStop = true;
            this.radioButtonTomato.Text = "Tomato";
            this.radioButtonTomato.UseVisualStyleBackColor = true;
            this.radioButtonTomato.CheckedChanged += new System.EventHandler(this.radioButtonTomato_CheckedChanged);
            // 
            // radioButtonChilliSauce
            // 
            this.radioButtonChilliSauce.AutoSize = true;
            this.radioButtonChilliSauce.Location = new System.Drawing.Point(6, 47);
            this.radioButtonChilliSauce.Name = "radioButtonChilliSauce";
            this.radioButtonChilliSauce.Size = new System.Drawing.Size(80, 17);
            this.radioButtonChilliSauce.TabIndex = 2;
            this.radioButtonChilliSauce.TabStop = true;
            this.radioButtonChilliSauce.Text = "Chilli Sauce";
            this.radioButtonChilliSauce.UseVisualStyleBackColor = true;
            this.radioButtonChilliSauce.CheckedChanged += new System.EventHandler(this.radioButtonChilliSauce_CheckedChanged);
            // 
            // radioButtonBBQSauce
            // 
            this.radioButtonBBQSauce.AutoSize = true;
            this.radioButtonBBQSauce.Location = new System.Drawing.Point(6, 24);
            this.radioButtonBBQSauce.Name = "radioButtonBBQSauce";
            this.radioButtonBBQSauce.Size = new System.Drawing.Size(81, 17);
            this.radioButtonBBQSauce.TabIndex = 1;
            this.radioButtonBBQSauce.TabStop = true;
            this.radioButtonBBQSauce.Text = "BBQ Sauce";
            this.radioButtonBBQSauce.UseVisualStyleBackColor = true;
            this.radioButtonBBQSauce.CheckedChanged += new System.EventHandler(this.radioButtonBBQSauce_CheckedChanged);
            // 
            // groupBoxReserve
            // 
            this.groupBoxReserve.Location = new System.Drawing.Point(218, 141);
            this.groupBoxReserve.Name = "groupBoxReserve";
            this.groupBoxReserve.Size = new System.Drawing.Size(200, 123);
            this.groupBoxReserve.TabIndex = 3;
            this.groupBoxReserve.TabStop = false;
            this.groupBoxReserve.Text = "Reserve";
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Location = new System.Drawing.Point(9, 280);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(118, 13);
            this.labelTitle.TabIndex = 4;
            this.labelTitle.Text = "- Coustomer Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 316);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Name:";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(69, 313);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(140, 20);
            this.textBoxName.TabIndex = 8;
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Location = new System.Drawing.Point(69, 365);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(140, 20);
            this.textBoxAddress.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 368);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Address:";
            // 
            // textBoxPhone
            // 
            this.textBoxPhone.Location = new System.Drawing.Point(69, 339);
            this.textBoxPhone.Name = "textBoxPhone";
            this.textBoxPhone.Size = new System.Drawing.Size(140, 20);
            this.textBoxPhone.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Phone:";
            // 
            // buttonSubmite
            // 
            this.buttonSubmite.Location = new System.Drawing.Point(218, 313);
            this.buttonSubmite.Name = "buttonSubmite";
            this.buttonSubmite.Size = new System.Drawing.Size(394, 72);
            this.buttonSubmite.TabIndex = 13;
            this.buttonSubmite.Text = "Submite";
            this.buttonSubmite.UseVisualStyleBackColor = true;
            this.buttonSubmite.Click += new System.EventHandler(this.buttonSubmite_Click);
            // 
            // labelReserve
            // 
            this.labelReserve.AutoSize = true;
            this.labelReserve.Location = new System.Drawing.Point(9, 13);
            this.labelReserve.Name = "labelReserve";
            this.labelReserve.Size = new System.Drawing.Size(80, 13);
            this.labelReserve.TabIndex = 14;
            this.labelReserve.Text = "Ready for order";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.buttonAbout);
            this.panel1.Controls.Add(this.labelReserve);
            this.panel1.Location = new System.Drawing.Point(0, 406);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(624, 36);
            this.panel1.TabIndex = 15;
            // 
            // buttonAbout
            // 
            this.buttonAbout.Location = new System.Drawing.Point(516, 5);
            this.buttonAbout.Name = "buttonAbout";
            this.buttonAbout.Size = new System.Drawing.Size(96, 28);
            this.buttonAbout.TabIndex = 16;
            this.buttonAbout.Text = "About";
            this.buttonAbout.UseVisualStyleBackColor = true;
            this.buttonAbout.Click += new System.EventHandler(this.buttonAbout_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonSubmite);
            this.Controls.Add(this.textBoxPhone);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxAddress);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.groupBoxReserve);
            this.Controls.Add(this.groupBoxSauces);
            this.Controls.Add(this.groupBoxDeliveryType);
            this.Controls.Add(this.groupBoxPizzaBase);
            this.Controls.Add(this.groupBoxMeat);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(640, 480);
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "Form1";
            this.Text = "Exercise 5 - Intro to variables";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxMeat.ResumeLayout(false);
            this.groupBoxMeat.PerformLayout();
            this.groupBoxPizzaBase.ResumeLayout(false);
            this.groupBoxPizzaBase.PerformLayout();
            this.groupBoxDeliveryType.ResumeLayout(false);
            this.groupBoxDeliveryType.PerformLayout();
            this.groupBoxSauces.ResumeLayout(false);
            this.groupBoxSauces.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxMeat;
        private System.Windows.Forms.GroupBox groupBoxPizzaBase;
        private System.Windows.Forms.GroupBox groupBoxDeliveryType;
        private System.Windows.Forms.GroupBox groupBoxSauces;
        private System.Windows.Forms.GroupBox groupBoxReserve;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxPhone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonSubmite;
        private System.Windows.Forms.Label labelReserve;
        private System.Windows.Forms.CheckBox checkBoxTuna;
        private System.Windows.Forms.CheckBox checkBoxAnchovise;
        private System.Windows.Forms.CheckBox checkBoxPrawn;
        private System.Windows.Forms.CheckBox checkBoxMince;
        private System.Windows.Forms.CheckBox checkBoxHotSalami;
        private System.Windows.Forms.CheckBox checkBoxSalami;
        private System.Windows.Forms.CheckBox checkBoxChicken;
        private System.Windows.Forms.RadioButton radioButtonDeepPan;
        private System.Windows.Forms.RadioButton radioButtonTraditionalCrust;
        private System.Windows.Forms.RadioButton radioButtonPickup;
        private System.Windows.Forms.RadioButton radioButtonDelivered;
        private System.Windows.Forms.RadioButton radioButtonGarlicSauce;
        private System.Windows.Forms.RadioButton radioButtonTomato;
        private System.Windows.Forms.RadioButton radioButtonChilliSauce;
        private System.Windows.Forms.RadioButton radioButtonBBQSauce;
        private System.Windows.Forms.RadioButton radioButtonCrispyCrust;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonAbout;
    }
}

