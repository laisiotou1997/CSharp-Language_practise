﻿namespace Exercise_6___Percentage_Check_Program
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxMouth = new System.Windows.Forms.PictureBox();
            this.pictureBoxEars = new System.Windows.Forms.PictureBox();
            this.pictureBoxEyes = new System.Windows.Forms.PictureBox();
            this.labelMouth = new System.Windows.Forms.Label();
            this.labelEyes = new System.Windows.Forms.Label();
            this.labelEars = new System.Windows.Forms.Label();
            this.textBoxMouth = new System.Windows.Forms.TextBox();
            this.textBoxEars = new System.Windows.Forms.TextBox();
            this.textBoxEyes = new System.Windows.Forms.TextBox();
            this.labelTitle = new System.Windows.Forms.Label();
            this.buttonMouth = new System.Windows.Forms.Button();
            this.buttonEyes = new System.Windows.Forms.Button();
            this.buttonEars = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelReserve = new System.Windows.Forms.Label();
            this.buttonAbout = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMouth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEyes)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBoxMouth
            // 
            this.pictureBoxMouth.Image = global::Exercise_6___Percentage_Check_Program.Properties.Resources.Speak_No_Evil_Monkey_Emoji_large;
            this.pictureBoxMouth.Location = new System.Drawing.Point(57, 105);
            this.pictureBoxMouth.Name = "pictureBoxMouth";
            this.pictureBoxMouth.Size = new System.Drawing.Size(112, 103);
            this.pictureBoxMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxMouth.TabIndex = 0;
            this.pictureBoxMouth.TabStop = false;
            // 
            // pictureBoxEars
            // 
            this.pictureBoxEars.Image = global::Exercise_6___Percentage_Check_Program.Properties.Resources.Hear_No_Evil_Monkey_Emoji_grande;
            this.pictureBoxEars.Location = new System.Drawing.Point(442, 105);
            this.pictureBoxEars.Name = "pictureBoxEars";
            this.pictureBoxEars.Size = new System.Drawing.Size(112, 103);
            this.pictureBoxEars.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEars.TabIndex = 1;
            this.pictureBoxEars.TabStop = false;
            // 
            // pictureBoxEyes
            // 
            this.pictureBoxEyes.Image = global::Exercise_6___Percentage_Check_Program.Properties.Resources.See_No_Evil_Monkey_Emoji_large;
            this.pictureBoxEyes.Location = new System.Drawing.Point(251, 105);
            this.pictureBoxEyes.Name = "pictureBoxEyes";
            this.pictureBoxEyes.Size = new System.Drawing.Size(112, 103);
            this.pictureBoxEyes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEyes.TabIndex = 2;
            this.pictureBoxEyes.TabStop = false;
            // 
            // labelMouth
            // 
            this.labelMouth.AutoSize = true;
            this.labelMouth.Location = new System.Drawing.Point(104, 89);
            this.labelMouth.Name = "labelMouth";
            this.labelMouth.Size = new System.Drawing.Size(20, 13);
            this.labelMouth.TabIndex = 3;
            this.labelMouth.Text = "#1";
            // 
            // labelEyes
            // 
            this.labelEyes.AutoSize = true;
            this.labelEyes.Location = new System.Drawing.Point(299, 89);
            this.labelEyes.Name = "labelEyes";
            this.labelEyes.Size = new System.Drawing.Size(20, 13);
            this.labelEyes.TabIndex = 4;
            this.labelEyes.Text = "#2";
            // 
            // labelEars
            // 
            this.labelEars.AutoSize = true;
            this.labelEars.Location = new System.Drawing.Point(488, 89);
            this.labelEars.Name = "labelEars";
            this.labelEars.Size = new System.Drawing.Size(20, 13);
            this.labelEars.TabIndex = 5;
            this.labelEars.Text = "#3";
            // 
            // textBoxMouth
            // 
            this.textBoxMouth.Location = new System.Drawing.Point(57, 237);
            this.textBoxMouth.Name = "textBoxMouth";
            this.textBoxMouth.Size = new System.Drawing.Size(112, 20);
            this.textBoxMouth.TabIndex = 6;
            // 
            // textBoxEars
            // 
            this.textBoxEars.Location = new System.Drawing.Point(442, 237);
            this.textBoxEars.Name = "textBoxEars";
            this.textBoxEars.Size = new System.Drawing.Size(112, 20);
            this.textBoxEars.TabIndex = 7;
            // 
            // textBoxEyes
            // 
            this.textBoxEyes.Location = new System.Drawing.Point(251, 237);
            this.textBoxEyes.Name = "textBoxEyes";
            this.textBoxEyes.Size = new System.Drawing.Size(112, 20);
            this.textBoxEyes.TabIndex = 8;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(209, 9);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelTitle.Size = new System.Drawing.Size(191, 20);
            this.labelTitle.TabIndex = 9;
            this.labelTitle.Text = "Nelson LAI s10000399";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonMouth
            // 
            this.buttonMouth.Location = new System.Drawing.Point(57, 287);
            this.buttonMouth.Name = "buttonMouth";
            this.buttonMouth.Size = new System.Drawing.Size(112, 23);
            this.buttonMouth.TabIndex = 10;
            this.buttonMouth.Text = "Rate This #1";
            this.buttonMouth.UseVisualStyleBackColor = true;
            this.buttonMouth.Click += new System.EventHandler(this.buttonMouth_Click);
            // 
            // buttonEyes
            // 
            this.buttonEyes.Location = new System.Drawing.Point(251, 287);
            this.buttonEyes.Name = "buttonEyes";
            this.buttonEyes.Size = new System.Drawing.Size(112, 23);
            this.buttonEyes.TabIndex = 11;
            this.buttonEyes.Text = "Rate This #2";
            this.buttonEyes.UseVisualStyleBackColor = true;
            this.buttonEyes.Click += new System.EventHandler(this.buttonEyes_Click);
            // 
            // buttonEars
            // 
            this.buttonEars.Location = new System.Drawing.Point(442, 287);
            this.buttonEars.Name = "buttonEars";
            this.buttonEars.Size = new System.Drawing.Size(112, 23);
            this.buttonEars.TabIndex = 12;
            this.buttonEars.Text = "Rate This #3";
            this.buttonEars.UseVisualStyleBackColor = true;
            this.buttonEars.Click += new System.EventHandler(this.buttonEars_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.buttonAbout);
            this.panel1.Controls.Add(this.labelReserve);
            this.panel1.Location = new System.Drawing.Point(-1, 397);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(626, 47);
            this.panel1.TabIndex = 13;
            // 
            // labelReserve
            // 
            this.labelReserve.AutoSize = true;
            this.labelReserve.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReserve.Location = new System.Drawing.Point(13, 16);
            this.labelReserve.Name = "labelReserve";
            this.labelReserve.Size = new System.Drawing.Size(43, 13);
            this.labelReserve.TabIndex = 0;
            this.labelReserve.Text = "Ready";
            // 
            // buttonAbout
            // 
            this.buttonAbout.Location = new System.Drawing.Point(538, 12);
            this.buttonAbout.Name = "buttonAbout";
            this.buttonAbout.Size = new System.Drawing.Size(75, 23);
            this.buttonAbout.TabIndex = 1;
            this.buttonAbout.Text = "About";
            this.buttonAbout.UseVisualStyleBackColor = true;
            this.buttonAbout.Click += new System.EventHandler(this.buttonAbout_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonEars);
            this.Controls.Add(this.buttonEyes);
            this.Controls.Add(this.buttonMouth);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.textBoxEyes);
            this.Controls.Add(this.textBoxEars);
            this.Controls.Add(this.textBoxMouth);
            this.Controls.Add(this.labelEars);
            this.Controls.Add(this.labelEyes);
            this.Controls.Add(this.labelMouth);
            this.Controls.Add(this.pictureBoxEyes);
            this.Controls.Add(this.pictureBoxEars);
            this.Controls.Add(this.pictureBoxMouth);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(640, 480);
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Exercise 6 - Percentage Check Program";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMouth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEyes)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxMouth;
        private System.Windows.Forms.PictureBox pictureBoxEars;
        private System.Windows.Forms.PictureBox pictureBoxEyes;
        private System.Windows.Forms.Label labelMouth;
        private System.Windows.Forms.Label labelEyes;
        private System.Windows.Forms.Label labelEars;
        private System.Windows.Forms.TextBox textBoxMouth;
        private System.Windows.Forms.TextBox textBoxEars;
        private System.Windows.Forms.TextBox textBoxEyes;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Button buttonMouth;
        private System.Windows.Forms.Button buttonEyes;
        private System.Windows.Forms.Button buttonEars;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonAbout;
        private System.Windows.Forms.Label labelReserve;
    }
}

