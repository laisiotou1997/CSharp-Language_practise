﻿namespace Assessment_Task_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonAbout = new System.Windows.Forms.Button();
            this.labelOrderTitle = new System.Windows.Forms.Label();
            this.groupBoxOption = new System.Windows.Forms.GroupBox();
            this.radioButtonHomeD = new System.Windows.Forms.RadioButton();
            this.radioButtonTakeAway = new System.Windows.Forms.RadioButton();
            this.groupBoxFood = new System.Windows.Forms.GroupBox();
            this.radioButtonSalami = new System.Windows.Forms.RadioButton();
            this.radioButtonChicken = new System.Windows.Forms.RadioButton();
            this.radioButtonPrawns = new System.Windows.Forms.RadioButton();
            this.radioButtonBeef = new System.Windows.Forms.RadioButton();
            this.radioButtonAnchovies = new System.Windows.Forms.RadioButton();
            this.labelTitle = new System.Windows.Forms.Label();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.labelOrderedFood = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBoxOption.SuspendLayout();
            this.groupBoxFood.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Controls.Add(this.labelOrderedFood);
            this.panel1.Controls.Add(this.buttonSubmit);
            this.panel1.Controls.Add(this.buttonAbout);
            this.panel1.Controls.Add(this.labelOrderTitle);
            this.panel1.Location = new System.Drawing.Point(194, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(419, 316);
            this.panel1.TabIndex = 17;
            // 
            // buttonAbout
            // 
            this.buttonAbout.Location = new System.Drawing.Point(220, 290);
            this.buttonAbout.Name = "buttonAbout";
            this.buttonAbout.Size = new System.Drawing.Size(200, 23);
            this.buttonAbout.TabIndex = 12;
            this.buttonAbout.Text = "About";
            this.buttonAbout.UseVisualStyleBackColor = true;
            this.buttonAbout.Click += new System.EventHandler(this.buttonAbout_Click);
            // 
            // labelOrderTitle
            // 
            this.labelOrderTitle.AutoSize = true;
            this.labelOrderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrderTitle.Location = new System.Drawing.Point(3, 0);
            this.labelOrderTitle.Name = "labelOrderTitle";
            this.labelOrderTitle.Size = new System.Drawing.Size(70, 24);
            this.labelOrderTitle.TabIndex = 1;
            this.labelOrderTitle.Text = "Order:";
            this.labelOrderTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBoxOption
            // 
            this.groupBoxOption.Controls.Add(this.radioButtonHomeD);
            this.groupBoxOption.Controls.Add(this.radioButtonTakeAway);
            this.groupBoxOption.Location = new System.Drawing.Point(13, 264);
            this.groupBoxOption.Name = "groupBoxOption";
            this.groupBoxOption.Size = new System.Drawing.Size(148, 100);
            this.groupBoxOption.TabIndex = 16;
            this.groupBoxOption.TabStop = false;
            this.groupBoxOption.Text = "Option";
            // 
            // radioButtonHomeD
            // 
            this.radioButtonHomeD.AutoSize = true;
            this.radioButtonHomeD.Location = new System.Drawing.Point(21, 59);
            this.radioButtonHomeD.Name = "radioButtonHomeD";
            this.radioButtonHomeD.Size = new System.Drawing.Size(99, 17);
            this.radioButtonHomeD.TabIndex = 8;
            this.radioButtonHomeD.TabStop = true;
            this.radioButtonHomeD.Text = "Home delivered";
            this.radioButtonHomeD.UseVisualStyleBackColor = true;
            // 
            // radioButtonTakeAway
            // 
            this.radioButtonTakeAway.AutoSize = true;
            this.radioButtonTakeAway.Location = new System.Drawing.Point(21, 31);
            this.radioButtonTakeAway.Name = "radioButtonTakeAway";
            this.radioButtonTakeAway.Size = new System.Drawing.Size(78, 17);
            this.radioButtonTakeAway.TabIndex = 7;
            this.radioButtonTakeAway.TabStop = true;
            this.radioButtonTakeAway.Text = "Take-away";
            this.radioButtonTakeAway.UseVisualStyleBackColor = true;
            // 
            // groupBoxFood
            // 
            this.groupBoxFood.Controls.Add(this.radioButtonSalami);
            this.groupBoxFood.Controls.Add(this.radioButtonChicken);
            this.groupBoxFood.Controls.Add(this.radioButtonPrawns);
            this.groupBoxFood.Controls.Add(this.radioButtonBeef);
            this.groupBoxFood.Controls.Add(this.radioButtonAnchovies);
            this.groupBoxFood.Location = new System.Drawing.Point(13, 48);
            this.groupBoxFood.Name = "groupBoxFood";
            this.groupBoxFood.Size = new System.Drawing.Size(148, 180);
            this.groupBoxFood.TabIndex = 15;
            this.groupBoxFood.TabStop = false;
            this.groupBoxFood.Text = "Food";
            // 
            // radioButtonSalami
            // 
            this.radioButtonSalami.AutoSize = true;
            this.radioButtonSalami.Location = new System.Drawing.Point(21, 28);
            this.radioButtonSalami.Name = "radioButtonSalami";
            this.radioButtonSalami.Size = new System.Drawing.Size(56, 17);
            this.radioButtonSalami.TabIndex = 2;
            this.radioButtonSalami.TabStop = true;
            this.radioButtonSalami.Text = "Salami";
            this.radioButtonSalami.UseVisualStyleBackColor = true;
            // 
            // radioButtonChicken
            // 
            this.radioButtonChicken.AutoSize = true;
            this.radioButtonChicken.Location = new System.Drawing.Point(21, 56);
            this.radioButtonChicken.Name = "radioButtonChicken";
            this.radioButtonChicken.Size = new System.Drawing.Size(64, 17);
            this.radioButtonChicken.TabIndex = 3;
            this.radioButtonChicken.TabStop = true;
            this.radioButtonChicken.Text = "Chicken";
            this.radioButtonChicken.UseVisualStyleBackColor = true;
            // 
            // radioButtonPrawns
            // 
            this.radioButtonPrawns.AutoSize = true;
            this.radioButtonPrawns.Location = new System.Drawing.Point(21, 84);
            this.radioButtonPrawns.Name = "radioButtonPrawns";
            this.radioButtonPrawns.Size = new System.Drawing.Size(60, 17);
            this.radioButtonPrawns.TabIndex = 4;
            this.radioButtonPrawns.TabStop = true;
            this.radioButtonPrawns.Text = "Prawns";
            this.radioButtonPrawns.UseVisualStyleBackColor = true;
            // 
            // radioButtonBeef
            // 
            this.radioButtonBeef.AutoSize = true;
            this.radioButtonBeef.Location = new System.Drawing.Point(21, 112);
            this.radioButtonBeef.Name = "radioButtonBeef";
            this.radioButtonBeef.Size = new System.Drawing.Size(47, 17);
            this.radioButtonBeef.TabIndex = 5;
            this.radioButtonBeef.TabStop = true;
            this.radioButtonBeef.Text = "Beef";
            this.radioButtonBeef.UseVisualStyleBackColor = true;
            // 
            // radioButtonAnchovies
            // 
            this.radioButtonAnchovies.AutoSize = true;
            this.radioButtonAnchovies.Location = new System.Drawing.Point(21, 140);
            this.radioButtonAnchovies.Name = "radioButtonAnchovies";
            this.radioButtonAnchovies.Size = new System.Drawing.Size(75, 17);
            this.radioButtonAnchovies.TabIndex = 6;
            this.radioButtonAnchovies.TabStop = true;
            this.radioButtonAnchovies.Text = "Anchovies";
            this.radioButtonAnchovies.UseVisualStyleBackColor = true;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(95, 9);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(389, 25);
            this.labelTitle.TabIndex = 14;
            this.labelTitle.Text = "Simple Order by Nelson LAI s10000399";
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Location = new System.Drawing.Point(3, 290);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(202, 23);
            this.buttonSubmit.TabIndex = 13;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // labelOrderedFood
            // 
            this.labelOrderedFood.AutoSize = true;
            this.labelOrderedFood.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrderedFood.Location = new System.Drawing.Point(3, 38);
            this.labelOrderedFood.Name = "labelOrderedFood";
            this.labelOrderedFood.Size = new System.Drawing.Size(0, 20);
            this.labelOrderedFood.TabIndex = 14;
            this.labelOrderedFood.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBoxOption);
            this.Controls.Add(this.groupBoxFood);
            this.Controls.Add(this.labelTitle);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBoxOption.ResumeLayout(false);
            this.groupBoxOption.PerformLayout();
            this.groupBoxFood.ResumeLayout(false);
            this.groupBoxFood.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonAbout;
        private System.Windows.Forms.Label labelOrderTitle;
        private System.Windows.Forms.GroupBox groupBoxOption;
        private System.Windows.Forms.RadioButton radioButtonHomeD;
        private System.Windows.Forms.RadioButton radioButtonTakeAway;
        private System.Windows.Forms.GroupBox groupBoxFood;
        private System.Windows.Forms.RadioButton radioButtonSalami;
        private System.Windows.Forms.RadioButton radioButtonChicken;
        private System.Windows.Forms.RadioButton radioButtonPrawns;
        private System.Windows.Forms.RadioButton radioButtonBeef;
        private System.Windows.Forms.RadioButton radioButtonAnchovies;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Label labelOrderedFood;
    }
}

